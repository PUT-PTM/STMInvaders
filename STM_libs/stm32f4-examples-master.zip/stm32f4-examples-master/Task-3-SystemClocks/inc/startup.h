#include "stm32f4xx.h"
#include "stm32f4xx_rcc.h"

uint32_t SystemInit(void);
void RCC_WaitForPLLSturtUp(void);
